﻿# LM Studio 本地模型集成说明

## 概述

RAI现在支持调用本地LM Studio API接口,让您可以在本地运行大语言模型并通过RAI网页界面访问。

## 前置条件

1. **安装LM Studio**: 从 [https://lmstudio.ai/](https://lmstudio.ai/) 下载并安装LM Studio
2. **下载模型**: 在LM Studio中下载您想使用的模型(例如Llama、Mistral等)
3. **启动本地服务器**: 在LM Studio中启动本地API服务器

## LM Studio配置步骤

### 1. 启动LM Studio服务器

1. 打开LM Studio应用
2. 加载您下载的模型
3. 点击"Local Server"标签
4. 点击"Start Server"按钮
5. 确保服务器运行在 `http://localhost:1234` (这是默认地址)

### 2. 在RAI中选择本地模型

1. 访问您的RAI网页界面
2. 在输入框工具栏中,点击模型选择下拉菜单
3. 选择 **"LMStudio Local"** 选项
4. 现在您的消息将发送到本地LM Studio模型

## 技术细节

### 后端配置 (server.js)

已在`API_PROVIDERS`中添加lmstudio配置:

```javascript
lmstudio: {
    apiKey: 'REDACTED_API_KEY',  // LM Studio 本地API不需要密钥
    baseURL: 'http://localhost:1234/v1/chat/completions',
    models: ['local-model']
}
```

### 模型路由配置

已在`MODEL_ROUTING`中添加:

```javascript
'lmstudio-local': {
    provider: 'lmstudio',
    model: 'local-model',
    supportsThinking: false  // 本地模型通常不支持推理模式
}
```

## 注意事项

1. **网络访问**: 
   - 如果RAI运行在云端VPS上,而LM Studio运行在本地,默认的`localhost:1234`将无法访问
   - 需要修改配置为可访问的IP地址,例如:`http://您的本地IP:1234`
   
2. **端口转发**: 
   - 如果需要从云端访问本地LM Studio,可使用SSH隧道或其他端口转发工具
   - 示例SSH隧道命令:
     ```bash
     ssh -R 1234:localhost:1234 user@your-vps-ip
     ```

3. **推理模式**: 
   - 本地模型默认不支持DeepSeek式的推理模式
   - 如果您的本地模型支持,可在配置中将`supportsThinking`设为`true`

4. **性能**: 
   - 本地模型的响应速度取决于您的硬件配置
   - 建议使用至少8GB显存的GPU以获得良好体验

## 常见问题

### Q: 为什么选择LMStudio Local后没有响应?

A: 请检查:
- LM Studio服务器是否正在运行
- 服务器地址是否为`localhost:1234`
- 浏览器控制台是否有错误信息
- 如果RAI在云端,检查网络连接配置

### Q: 如何更改LM Studio端口?

A: 修改`server.js`中的配置:
```javascript
lmstudio: {
    apiKey: 'REDACTED_API_KEY',
    baseURL: 'http://localhost:YOUR_PORT/v1/chat/completions',  // 更改YOUR_PORT
    models: ['local-model']
}
```

### Q: 可以同时使用多个本地模型吗?

A: 可以,您需要:
1. 在`API_PROVIDERS`中添加更多配置
2. 在`MODEL_ROUTING`中添加相应路由
3. 在前端添加对应的选项

## 云端VPS访问本地模型的解决方案

由于您的RAI运行在云端Debian VPS上,以下是几种访问本地LM Studio的方案:

### 方案1: SSH反向隧道 (推荐)

在您的本地机器上运行:
```bash
ssh -N -R 1234:localhost:1234 your_username@your_vps_ip
```

这会将VPS的1234端口转发到您本地的1234端口。

### 方案2: 修改为公网访问

1. 在本地路由器上配置端口转发(1234端口)
2. 修改`server.js`配置,将`localhost`改为您的公网IP
3. ⚠️ 注意安全风险,建议配置防火墙规则

### 方案3: 使用Ngrok等内网穿透工具

```bash
ngrok http 1234
```

然后将生成的公网地址更新到`server.js`配置中。

## 更新日志

- **2025-11-28**: 
  - 添加LM Studio本地API支持
  - 在模型列表中添加"LMStudio Local"选项
  - 更新后端API配置和模型路由
