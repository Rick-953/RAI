param([Parameter(Mandatory=$true)][string]$CacheDirectory)
$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -eq 'ARM64') {
    throw 'The pinned docx-cli standalone executable requires Windows x64.'
}
$cacheRoot = [IO.Path]::GetFullPath($CacheDirectory)
[void][IO.Directory]::CreateDirectory($cacheRoot)
$binaryPath = Join-Path $cacheRoot 'docx-v0.28.0.exe'
$expectedHash = '48a652079f6838ff3dc3fc613481e8a545fd9f0acd4d620f2cc03a80872378d3'
if (Test-Path -LiteralPath $binaryPath) {
    if ((Get-FileHash -LiteralPath $binaryPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) {
        throw 'Cached docx-cli checksum mismatch. Remove this executable before retrying.'
    }
} else {
    $downloadPath = Join-Path $cacheRoot ('docx-' + [Guid]::NewGuid().ToString('N') + '.download')
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/kklimuk/docx-cli/releases/download/v0.28.0/docx-windows-x64.exe' -OutFile $downloadPath
        if ((Get-FileHash -LiteralPath $downloadPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) {
            throw 'Downloaded docx-cli checksum mismatch; executable was not installed.'
        }
        Move-Item -LiteralPath $downloadPath -Destination $binaryPath
    } finally {
        if (Test-Path -LiteralPath $downloadPath) { Remove-Item -LiteralPath $downloadPath }
    }
}
Write-Output $binaryPath
